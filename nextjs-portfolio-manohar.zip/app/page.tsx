
export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Hello, I'm Chamakuri Manohar 👋</h1>
      <p>B.Tech graduate in CSE (Data Science) from SVEC (JNTUA). Passionate about AI, data analytics, and Python development.</p>
      <h2>Projects</h2>
      <ul>
        <li><strong>SMS Spam Filter</strong> – Python, Scikit-learn, Pandas<br />A machine learning model to classify spam messages with 95% accuracy.</li>
        <li><strong>AI-Based Quality Data Analytics</strong> – Python, Excel<br />Analyzed datasets and built scripts to detect anomalies.</li>
      </ul>
      <h2>Skills</h2>
      <p>Python, Pandas, NumPy, SQL, Scikit-learn, Git, HTML/CSS</p>
      <h2>Contact</h2>
      <p>Email: chamakurimanohar169@gmail.com</p>
      <p>GitHub: <a href="https://github.com/chamakuri1929/portfolio-manohar-">chamakuri1929</a></p>
      <p>LinkedIn: <a href="https://www.linkedin.com/in/manohar-chamakuri-81b988264">manohar-chamakuri</a></p>
    </main>
  );
}
